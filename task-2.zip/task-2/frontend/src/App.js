import { useState } from "react";

function App() {
  const [page, setPage] = useState("login");
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [taskText, setTaskText] = useState("");

  async function login(e) {
    e.preventDefault();
    const res = await fetch("http://localhost:5000/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: e.target.email.value,
        password: e.target.password.value
      }),
    });

    const data = await res.json();
    if (data.token) {
      setUser(data);
      setPage("tasks");
      loadTasks(data.token);
    } else {
      alert(data.message || "Login failed");
    }
  }

  async function register(e) {
    e.preventDefault();
    const res = await fetch("http://localhost:5000/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: e.target.name.value,
        email: e.target.email.value,
        password: e.target.password.value,
      }),
    });

    const data = await res.json();
    alert(data.message);
    setPage("login");
  }

 async function loadTasks(token) {
  const res = await fetch("http://localhost:5000/api/tasks", {
    headers: { Authorization: `Bearer ${token}` },
  });

  const data = await res.json();

  // Prevent crash if backend sends an error
  if (Array.isArray(data)) {
    setTasks(data);
  } else {
    console.log("Error loading tasks:", data);
    setTasks([]);
  }
}

  async function addTask() {
  if (!taskText.trim()) return;

  const res = await fetch("http://localhost:5000/api/tasks", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${user.token}`,
    },
    body: JSON.stringify({ title: taskText }),  // FIXED
  });

  const newTask = await res.json();
  setTasks([...tasks, newTask]);
  setTaskText("");
}

  async function deleteTask(id) {
  await fetch(`http://localhost:5000/api/tasks/${id}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${user.token}` },
  });

  setTasks(tasks.filter((t) => t._id !== id));  // FIXED
}

  return (
    <div style={styles.container}>
      {page === "login" && (
        <form style={styles.box} onSubmit={login}>
          <h2>Login</h2>
          <input name="email" placeholder="Email" style={styles.input} />
          <input name="password" type="password" placeholder="Password" style={styles.input} />
          <button style={styles.button}>Login</button>
          <p onClick={() => setPage("register")} style={styles.link}>Create account</p>
        </form>
      )}

      {page === "register" && (
        <form style={styles.box} onSubmit={register}>
          <h2>Register</h2>
          <input name="name" placeholder="Name" style={styles.input} />
          <input name="email" placeholder="Email" style={styles.input} />
          <input name="password" type="password" placeholder="Password" style={styles.input} />
          <button style={styles.button}>Sign Up</button>
          <p onClick={() => setPage("login")} style={styles.link}>Back to Login</p>
        </form>
      )}

      {page === "tasks" && (
        <div style={styles.box}>
          <h2>Your Tasks</h2>
          <div style={{ display: "flex" }}>
            <input
              value={taskText}
              onChange={(e) => setTaskText(e.target.value)}
              placeholder="New Task..."
              style={styles.input}
            />
            <button onClick={addTask} style={styles.button}>Add</button>
          </div>

          <ul style={styles.list}>
           {tasks.map((t) => (
  <li key={t._id} style={styles.item}>   {/* FIXED */}
    {t.title}                             {/* FIXED */}
    <button onClick={() => deleteTask(t._id)} style={styles.delete}>
      X
    </button>
  </li>
))}
          </ul>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    background: "#f5f5f5",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  box: {
    width: "350px",
    padding: "20px",
    background: "white",
    borderRadius: "12px",
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
  },
  input: {
    width: "100%",
    padding: "10px",
    margin: "6px 0",
    borderRadius: "6px",
    border: "1px solid #ccc",
  },
  button: {
    padding: "10px",
    background: "blue",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    marginLeft: "10px",
  },
  link: {
    color: "blue",
    cursor: "pointer",
    marginTop: "10px",
    textAlign: "center",
  },
  list: {
    marginTop: "15px",
    padding: 0,
    listStyle: "none",
  },
  item: {
    background: "#eee",
    padding: "10px",
    margin: "5px 0",
    borderRadius: "6px",
    display: "flex",
    justifyContent: "space-between",
  },
  delete: {
    background: "red",
    color: "white",
    padding: "4px 8px",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
};

export default App;