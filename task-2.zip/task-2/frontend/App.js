import { useState } from "react";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Todo from "./pages/Todo";

export default function App() {
  const [auth, setAuth] = useState(localStorage.getItem("token") ? true : false);

  if (!auth)
    return (
      <>
        <Login setAuth={setAuth} />
        <Register />
      </>
    );

  return <Todo />;
}