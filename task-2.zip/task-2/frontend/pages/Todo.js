import { useEffect, useState } from "react";
import API from "../api";

export default function Todo() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");

  const loadTasks = async () => {
    const res = await API.get("/tasks");
    setTasks(res.data);
  };

  const addTask = async () => {
    await API.post("/tasks", { title });
    loadTasks();
  };

  const toggle = async (task) => {
    await API.put(`/tasks/${task._id}`, {
      completed: !task.completed,
      title: task.title
    });
    loadTasks();
  };

  const del = async (id) => {
    await API.delete(`/tasks/${id}`);
    loadTasks();
  };

  useEffect(() => {
    loadTasks();
  }, []);

  return (
    <div>
      <h2>My Tasks</h2>

      <input placeholder="New Task" onChange={(e) => setTitle(e.target.value)} />
      <button onClick={addTask}>Add</button>

      {tasks.map((t) => (
        <div key={t._id}>
          <input
            type="checkbox"
            checked={t.completed}
            onChange={() => toggle(t)}
          />
          {t.title}
          <button onClick={() => del(t._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}